# Missing files

Decompile the original `areaautopilot-1_10_2.jar` (Vineflower / CFR / IntelliJ) and put these here:

- AreaAutopilot.java
- AutopilotExt.java   (includes the nested BoolGet / BoolSet interfaces)
- AutopilotFly.java
- AutopilotPlus.java

`AutopilotTrail.java` (the v1.10.3 trail + cache code) is already in this folder.
Then delete this file.

## The two hook lines (in AutopilotPlus.java)

```java
public static void register(CommandDispatcher d) {
    AutopilotTrail.register(d);   // <-- add as the first line
    ...
}

public static void onTick(Object mc) {
    AutopilotTrail.onTick(mc);    // <-- add as the first line
    ...
}
```
