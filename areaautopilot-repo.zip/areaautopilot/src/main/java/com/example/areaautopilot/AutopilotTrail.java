package com.example.areaautopilot;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * v1.10.3 additions (reflection only, same style as AutopilotPlus/AutopilotExt):
 *  - /autopilot cache            : show what is held in memory
 *  - /autopilot cache clear      : reset points A/B, path, progress, column cache and the flight trail
 *  - /autopilot trail [on|off]   : show / hide the flight-path line
 *  - /autopilot trail color <name | #RRGGBB | r g b>
 *
 * Nothing here is ever triggered by a disconnect: the cache is only cleared by the command above.
 * Hooked in from AutopilotPlus.register (commands) and AutopilotPlus.onTick (every client tick).
 */
public final class AutopilotTrail {
    private AutopilotTrail() {}

    private static final String AP_NAME = "com.example.areaautopilot.AreaAutopilot";
    private static final String EXT_NAME = "com.example.areaautopilot.AutopilotExt";
    private static final String PLUS_NAME = "com.example.areaautopilot.AutopilotPlus";
    private static final String MC_NAME = "net.minecraft.client.Minecraft";

    private static final Map<String, Integer> NAMED = new LinkedHashMap<>();
    static {
        NAMED.put("red", 0xFF2020);
        NAMED.put("orange", 0xFF8000);
        NAMED.put("yellow", 0xFFFF00);
        NAMED.put("lime", 0x80FF00);
        NAMED.put("green", 0x00E000);
        NAMED.put("cyan", 0x00FFFF);
        NAMED.put("blue", 0x3050FF);
        NAMED.put("purple", 0xA030F0);
        NAMED.put("magenta", 0xFF00FF);
        NAMED.put("pink", 0xFF80C0);
        NAMED.put("white", 0xFFFFFF);
        NAMED.put("gray", 0x909090);
    }

    // ---- settings -------------------------------------------------------------------------
    private static boolean trailOn = true;
    private static int color = 0x00FFFF;
    private static String colorLabel = "cyan";
    private static boolean cfgLoaded;

    // ---- recorded trail points (x,y,z packed, grows on demand) ----------------------------
    private static double[] pts = new double[3 * 256];
    private static int count;
    private static double lastX, lastY, lastZ;
    private static boolean haveLast;

    private static int tickN;
    private static boolean warned;

    // ---- reflection caches ----------------------------------------------------------------
    private static final Map<String, Field> FIELDS = new HashMap<>();
    private static final Map<String, Method> METHODS = new HashMap<>();
    private static Object dustOpts;
    private static int dustColor = -1;
    private static Method particleM;
    private static Class<?> particleLevelClass;

    private static final double RANGE = 48.0;
    private static final int BUDGET = 600;
    private static final int EMIT_EVERY = 10;

    // =======================================================================================
    // commands
    // =======================================================================================
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static void register(CommandDispatcher dispatcher) {
        try {
            loadCfg();
            LiteralArgumentBuilder root = LiteralArgumentBuilder.literal("autopilot");

            // /autopilot cache , /autopilot cache clear
            LiteralArgumentBuilder cache = LiteralArgumentBuilder.literal("cache");
            Command cacheInfo = ctx -> { say(ctx, cacheSummary()); return 1; };
            Command cacheClear = ctx -> { say(ctx, clearAll()); return 1; };
            cache.executes(cacheInfo);
            LiteralArgumentBuilder clear = LiteralArgumentBuilder.literal("clear");
            clear.executes(cacheClear);
            cache.then(clear);
            root.then(cache);

            // /autopilot trail ...
            LiteralArgumentBuilder trail = LiteralArgumentBuilder.literal("trail");
            Command trailInfo = ctx -> { say(ctx, trailStatus()); return 1; };
            trail.executes(trailInfo);

            LiteralArgumentBuilder on = LiteralArgumentBuilder.literal("on");
            Command onCmd = ctx -> { trailOn = true; saveCfg(); say(ctx, "Flight trail ON. " + trailStatus()); return 1; };
            on.executes(onCmd);
            trail.then(on);

            LiteralArgumentBuilder off = LiteralArgumentBuilder.literal("off");
            Command offCmd = ctx -> { trailOn = false; saveCfg(); say(ctx, "Flight trail OFF (points are still recorded while flying; use /autopilot cache clear to wipe them)."); return 1; };
            off.executes(offCmd);
            trail.then(off);

            LiteralArgumentBuilder col = LiteralArgumentBuilder.literal("color");
            Command colInfo = ctx -> { say(ctx, "Trail color: " + colorLabel + ". Use /autopilot trail color <" + names() + " | #RRGGBB | r g b>"); return 1; };
            col.executes(colInfo);
            RequiredArgumentBuilder val = RequiredArgumentBuilder.argument("value", StringArgumentType.greedyString());
            Command colSet = ctx -> {
                String in = StringArgumentType.getString(ctx, "value");
                int c = parseColor(in);
                if (c < 0) {
                    say(ctx, "Unknown color '" + in + "'. Try: " + names() + ", #RRGGBB, or r g b (0-255 each).");
                    return 0;
                }
                color = c;
                colorLabel = labelFor(in, c);
                trailOn = true;
                saveCfg();
                say(ctx, "Trail color set to " + colorLabel + ".");
                return 1;
            };
            val.executes(colSet);
            col.then(val);
            trail.then(col);
            root.then(trail);

            dispatcher.register(root);
        } catch (Throwable t) {
            warn("register", t);
        }
    }

    private static String names() {
        return String.join(", ", NAMED.keySet());
    }

    private static String trailStatus() {
        return "Trail " + (trailOn ? "ON" : "OFF") + ", color " + colorLabel + ", " + count + " points recorded.";
    }

    private static String cacheSummary() {
        int cols = -1, wps = -1;
        try { cols = ((Map<?, ?>) getStatic(Class.forName(EXT_NAME), "COL")).size(); } catch (Throwable ignored) {}
        try { wps = ((List<?>) getStatic(Class.forName(AP_NAME), "path")).size(); } catch (Throwable ignored) {}
        long kb = ((long) pts.length * 8L) / 1024L;
        return "Memory: " + count + " trail points (~" + kb + " KB), " + (cols < 0 ? "?" : String.valueOf(cols))
                + " cached columns, " + (wps < 0 ? "?" : String.valueOf(wps)) + " waypoints. "
                + "/autopilot cache clear resets all of it plus points A/B and progress.";
    }

    // =======================================================================================
    // cache clear - ONLY runs from /autopilot cache clear, never on disconnect
    // =======================================================================================
    private static String clearAll() {
        int trailPts = count;
        int cols = 0, wps = 0;
        boolean wasRunning = false;
        Class<?> ap = null;
        try { ap = Class.forName(AP_NAME); } catch (Throwable t) { warn("clear/class", t); }
        if (ap != null) {
            try {
                Object r = getStatic(ap, "running");
                wasRunning = r instanceof Boolean && (Boolean) r;
                Object mc = mcInstance();
                if (wasRunning && mc != null) {
                    Method stop = ap.getDeclaredMethod("stop", Class.forName(MC_NAME));
                    stop.setAccessible(true);
                    stop.invoke(null, mc);
                }
            } catch (Throwable t) {
                warn("clear/stop", t);
            }
            try {
                Object p = getStatic(ap, "path");
                if (p instanceof List) wps = ((List<?>) p).size();
            } catch (Throwable ignored) {}
            // each reset is independent so one failure can't leave the rest of the state behind
            trySet(ap, "running", Boolean.FALSE);
            trySet(ap, "path", new ArrayList<int[]>());
            trySet(ap, "ax", null);
            trySet(ap, "az", null);
            trySet(ap, "bx", null);
            trySet(ap, "bz", null);
            trySet(ap, "idx", 0);
            trySet(ap, "landing", Boolean.FALSE);
            trySet(ap, "landTicks", 0);
            trySet(ap, "stuckTicks", 0);
            trySet(ap, "strafeTicks", 0);
        }
        try {
            Class<?> ext = Class.forName(EXT_NAME);
            Object colMap = getStatic(ext, "COL");
            if (colMap instanceof Map) cols = ((Map<?, ?>) colMap).size();
            Method rs = ext.getDeclaredMethod("resetSession");
            rs.setAccessible(true);
            rs.invoke(null);
        } catch (Throwable t) {
            warn("clear/ext", t);
        }
        clearTrail();
        try {
            // rewrite the saved-state file right away so the old A/B + progress don't come back on next join
            Class<?> plus = Class.forName(PLUS_NAME);
            Method w = plus.getDeclaredMethod("writeState");
            w.setAccessible(true);
            w.invoke(null);
        } catch (Throwable t) {
            warn("clear/state-file", t);
        }
        try { System.gc(); } catch (Throwable ignored) {}
        return "Cache cleared: " + trailPts + " trail points, " + cols + " cached columns, " + wps
                + " waypoints; points A/B and progress reset" + (wasRunning ? " (autopilot stopped)" : "") + ".";
    }

    private static void trySet(Class<?> c, String name, Object v) {
        try { setStatic(c, name, v); } catch (Throwable t) { warn("clear/" + name, t); }
    }

    private static void clearTrail() {
        pts = new double[3 * 256];
        count = 0;
        haveLast = false;
    }

    // =======================================================================================
    // per-tick: record + draw
    // =======================================================================================
    public static void onTick(Object mc) {
        try {
            if (mc == null) return;
            if (!cfgLoaded) loadCfg();
            Object player = fieldOf(mc, "player");
            Object level = fieldOf(mc, "level");
            if (player == null || level == null) return;
            tickN++;
            if (isRunning()) record(player);
            if (trailOn && tickN % EMIT_EVERY == 0) emit(level, player);
        } catch (Throwable t) {
            warn("tick", t);
        }
    }

    private static boolean isRunning() throws Exception {
        Object r = getStatic(Class.forName(AP_NAME), "running");
        return r instanceof Boolean && (Boolean) r;
    }

    private static void record(Object player) throws Exception {
        double x = num(player, "getX"), y = num(player, "getY") + 0.2, z = num(player, "getZ");
        if (haveLast) {
            double dx = x - lastX, dy = y - lastY, dz = z - lastZ;
            if (dx * dx + dy * dy + dz * dz < 0.64) return; // < 0.8 block since last point
        }
        if (count * 3 + 3 > pts.length) {
            double[] n = new double[pts.length + pts.length / 2];
            System.arraycopy(pts, 0, n, 0, count * 3);
            pts = n;
        }
        pts[count * 3] = x;
        pts[count * 3 + 1] = y;
        pts[count * 3 + 2] = z;
        count++;
        lastX = x; lastY = y; lastZ = z; haveLast = true;
    }

    private static void emit(Object level, Object player) throws Exception {
        Object opts = dust();
        Method m = particleMethod(level, opts);
        if (m == null) return;
        int extra = m.getParameterCount() - 7;
        double px = num(player, "getX"), py = num(player, "getY"), pz = num(player, "getZ");
        double r2 = RANGE * RANGE;
        if (isRunning()) emitAhead(m, extra, level, opts, px, py + 0.2, pz);
        int budget = BUDGET;
        for (int i = count - 1; i >= 0 && budget > 0; i--) {
            double x = pts[i * 3], y = pts[i * 3 + 1], z = pts[i * 3 + 2];
            double dx = x - px, dy = y - py, dz = z - pz;
            if (dx * dx + dy * dy + dz * dz > r2) continue;
            spawn(m, extra, level, opts, x, y, z);
            budget--;
            // fill the gap to the next point so the dots read as a continuous line
            if (i + 1 < count) {
                double nx = pts[i * 3 + 3], ny = pts[i * 3 + 4], nz = pts[i * 3 + 5];
                double gx = nx - x, gy = ny - y, gz = nz - z;
                double gap = Math.sqrt(gx * gx + gy * gy + gz * gz);
                if (gap > 1.3 && gap < 8.0) {
                    int steps = (int) Math.min(7, Math.floor(gap));
                    for (int s = 1; s < steps && budget > 0; s++) {
                        double f = (double) s / steps;
                        spawn(m, extra, level, opts, x + gx * f, y + gy * f, z + gz * f);
                        budget--;
                    }
                }
            }
        }
    }

    /** Draws the route still to come: player -> current waypoint -> following waypoints. */
    private static void emitAhead(Method m, int extra, Object level, Object opts, double px, double py, double pz) throws Exception {
        Class<?> ap = Class.forName(AP_NAME);
        Object po = getStatic(ap, "path");
        Object io = getStatic(ap, "idx");
        if (!(po instanceof List) || !(io instanceof Integer)) return;
        List<?> path = (List<?>) po;
        int idx = Math.max(0, (Integer) io);
        double r2 = RANGE * RANGE;
        int budget = 500;
        double cx = px, cz = pz;
        int last = Math.min(path.size(), idx + 12);
        for (int k = idx; k < last && budget > 0; k++) {
            int[] w = (int[]) path.get(k);
            double tx = w[0] + 0.5, tz = w[1] + 0.5;
            double dx = tx - cx, dz = tz - cz;
            double len = Math.sqrt(dx * dx + dz * dz);
            int steps = (int) Math.max(1, Math.ceil(len / 1.5));
            for (int s = 0; s <= steps && budget > 0; s++) {
                double f = (double) s / steps;
                double x = cx + dx * f, z = cz + dz * f;
                double ex = x - px, ez = z - pz;
                if (ex * ex + ez * ez > r2) continue;
                spawn(m, extra, level, opts, x, py, z);
                budget--;
            }
            cx = tx; cz = tz;
        }
    }

    private static void spawn(Method m, int bools, Object level, Object opts, double x, double y, double z) throws Exception {
        Object[] a = new Object[7 + bools];
        a[0] = opts;
        for (int i = 1; i <= bools; i++) a[i] = Boolean.TRUE;
        a[1 + bools] = x;
        a[2 + bools] = y;
        a[3 + bools] = z;
        a[4 + bools] = 0.0;
        a[5 + bools] = 0.0;
        a[6 + bools] = 0.0;
        m.invoke(level, a);
    }

    private static Object dust() throws Exception {
        if (dustOpts != null && dustColor == color) return dustOpts;
        Class<?> c = Class.forName("net.minecraft.core.particles.DustParticleOptions");
        Object o = null;
        for (Constructor<?> k : c.getConstructors()) {
            Class<?>[] p = k.getParameterTypes();
            if (p.length == 2 && p[0] == int.class && p[1] == float.class) {
                o = k.newInstance(0xFF000000 | color, 1.5f);
                break;
            }
        }
        if (o == null) { // older versions took a Vector3f
            Class<?> v = Class.forName("org.joml.Vector3f");
            for (Constructor<?> k : c.getConstructors()) {
                Class<?>[] p = k.getParameterTypes();
                if (p.length == 2 && p[0] == v && p[1] == float.class) {
                    Object vec = v.getConstructor(float.class, float.class, float.class)
                            .newInstance(((color >> 16) & 255) / 255f, ((color >> 8) & 255) / 255f, (color & 255) / 255f);
                    o = k.newInstance(vec, 1.5f);
                    break;
                }
            }
        }
        if (o == null) throw new IllegalStateException("DustParticleOptions constructor not found");
        dustOpts = o;
        dustColor = color;
        return o;
    }

    private static Method particleMethod(Object level, Object opts) {
        if (particleM != null && particleLevelClass == level.getClass()) return particleM;
        for (String name : new String[] {"addAlwaysVisibleParticle", "addParticle"}) {
            Method best = null;
            int bestB = 99;
            for (Method m : level.getClass().getMethods()) {
                if (!m.getName().equals(name)) continue;
                Class<?>[] p = m.getParameterTypes();
                if (p.length < 7 || !p[0].isInstance(opts)) continue;
                int b = 0, i = 1;
                while (i < p.length && p[i] == boolean.class) { b++; i++; }
                if (p.length - i != 6) continue;
                boolean ok = true;
                for (int j = i; j < p.length; j++) if (p[j] != double.class) ok = false;
                if (ok && b < bestB) { best = m; bestB = b; }
            }
            if (best != null) {
                try { best.setAccessible(true); } catch (Throwable ignored) {}
                particleM = best;
                particleLevelClass = level.getClass();
                return best;
            }
        }
        if (!warned) { warned = true; System.err.println("[areaautopilot] trail: no addParticle method found"); }
        return null;
    }

    // =======================================================================================
    // colors + config
    // =======================================================================================
    static int parseColor(String s) {
        if (s == null) return -1;
        s = s.trim().toLowerCase();
        if (s.isEmpty()) return -1;
        Integer n = NAMED.get(s);
        if (n != null) return n;
        try {
            String h = s.startsWith("#") ? s.substring(1) : s.startsWith("0x") ? s.substring(2) : s;
            if (h.matches("[0-9a-f]{6}")) return Integer.parseInt(h, 16);
            if (h.matches("[0-9a-f]{3}")) {
                int r = Character.digit(h.charAt(0), 16) * 17, g = Character.digit(h.charAt(1), 16) * 17, b = Character.digit(h.charAt(2), 16) * 17;
                return (r << 16) | (g << 8) | b;
            }
            String[] t = s.split("[\\s,]+");
            if (t.length == 3) {
                int r = Integer.parseInt(t[0]), g = Integer.parseInt(t[1]), b = Integer.parseInt(t[2]);
                if (r >= 0 && r <= 255 && g >= 0 && g <= 255 && b >= 0 && b <= 255) return (r << 16) | (g << 8) | b;
            }
        } catch (Throwable ignored) {}
        return -1;
    }

    private static String labelFor(String in, int c) {
        String k = in.trim().toLowerCase();
        return NAMED.containsKey(k) ? k : String.format("#%06X", c);
    }

    private static File cfg() { return new File("config", "areaautopilot-trail.properties"); }

    private static void loadCfg() {
        cfgLoaded = true;
        try {
            File f = cfg();
            if (!f.isFile()) return;
            Properties p = new Properties();
            try (FileInputStream in = new FileInputStream(f)) { p.load(in); }
            String on = p.getProperty("on");
            if (on != null) trailOn = Boolean.parseBoolean(on.trim());
            String c = p.getProperty("color");
            if (c != null) {
                int v = parseColor(c);
                if (v >= 0) { color = v; colorLabel = labelFor(c, v); }
            }
        } catch (Throwable t) {
            warn("loadCfg", t);
        }
    }

    private static void saveCfg() {
        try {
            File f = cfg();
            File dir = f.getParentFile();
            if (dir != null) dir.mkdirs();
            Properties p = new Properties();
            p.setProperty("on", String.valueOf(trailOn));
            p.setProperty("color", colorLabel);
            try (FileOutputStream out = new FileOutputStream(f)) { p.store(out, "Area Autopilot trail settings"); }
        } catch (Throwable t) {
            warn("saveCfg", t);
        }
    }

    // =======================================================================================
    // small reflection helpers
    // =======================================================================================
    private static void say(CommandContext<?> ctx, String msg) {
        try {
            Method m = Class.forName(AP_NAME).getDeclaredMethod("say", CommandContext.class, String.class);
            m.setAccessible(true);
            m.invoke(null, ctx, msg);
        } catch (Throwable t) {
            warn("say", t);
        }
    }

    private static Object mcInstance() {
        try {
            return Class.forName(MC_NAME).getMethod("getInstance").invoke(null);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Field findField(Class<?> c, String name) throws NoSuchFieldException {
        String key = c.getName() + "#" + name;
        Field f = FIELDS.get(key);
        if (f != null) return f;
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            try {
                f = k.getDeclaredField(name);
                f.setAccessible(true);
                FIELDS.put(key, f);
                return f;
            } catch (NoSuchFieldException ignored) {}
        }
        throw new NoSuchFieldException(key);
    }

    private static Object fieldOf(Object o, String name) throws Exception {
        return findField(o.getClass(), name).get(o);
    }

    private static Object getStatic(Class<?> c, String name) throws Exception {
        return findField(c, name).get(null);
    }

    private static void setStatic(Class<?> c, String name, Object v) throws Exception {
        findField(c, name).set(null, v);
    }

    private static double num(Object o, String method) throws Exception {
        String key = o.getClass().getName() + "#" + method;
        Method m = METHODS.get(key);
        if (m == null) {
            m = o.getClass().getMethod(method);
            m.setAccessible(true);
            METHODS.put(key, m);
        }
        return ((Number) m.invoke(o)).doubleValue();
    }

    private static void warn(String where, Throwable t) {
        if (warned) return;
        warned = true;
        System.err.println("[areaautopilot] trail/" + where + ": " + t);
    }
}
