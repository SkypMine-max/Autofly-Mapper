# Area Autopilot

Fabric client mod (Minecraft 26.1): pick two corners (X Z) and auto-walk or auto-fly (elytra) a sweep pattern over the whole area.

Original mod by "you" (CC0-1.0). v1.10.3 adds the manual cache clear and the flight-path line.

## Commands

All commands start with `/autopilot`.

| Command | What it does |
|---|---|
| `a [x z]`, `b [x z]` | Set corner A / B |
| `start`, `resume`, `stop` | Run, continue, or cancel the sweep |
| `startfrom <x> <z>` / `startfrom current` | Join the sweep at the nearest waypoint |
| `status` | Show corners, settings, progress |
| `spacing <1-512>` | Distance between lanes |
| `turnspeed <1-45>` | Degrees turned per tick (lower = smoother) |
| `elytra <true\|false>` | Elytra mode |
| `altitude <y>` / `altitude auto` | Cruise height (auto = start Y + 40) |
| `fireworks [auto\|true\|false]` | Whether fireworks are required |
| `durability <0-431>` | Land when elytra durability is at or below this |
| `minrockets <0-4096>` | Land when rockets are at or below this |
| `flyband [bool]`, `flyy <min> <max>` | Cruise Y band |
| `landband [bool]`, `landy <min> <max>` | Landing Y band |
| `elytraswap [bool]` | Auto-swap to a healthier elytra |
| `safeland [bool]` | Land only on a safe spot |
| `landnow` | Land immediately |
| `disconnect [bool]` | Leave the game after a safe landing |
| `extras`, `debug` | Extra settings / debug report |
| `trail [on\|off]` | Show or hide the flight-path line |
| `trail color <name \| #hex \| r g b>` | Line color |
| `cache` | Show what is held in memory |
| `cache clear` | Reset A/B, path, progress, caches and trail points |

`cache clear` only runs when you type it. It never runs on disconnect.

## Flight-path line

Drawn with dust particles within ~48 blocks: where you have been, plus the route still to come.
Settings are saved in `config/areaautopilot-trail.properties`.

## Building

Needs JDK 21. See the notes at the top of `build.gradle`, then `./gradlew build`.
The jar appears in `build/libs/`.
